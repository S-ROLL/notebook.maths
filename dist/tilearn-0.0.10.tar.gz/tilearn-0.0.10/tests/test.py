from tilearn2 import show

show(4, 5)