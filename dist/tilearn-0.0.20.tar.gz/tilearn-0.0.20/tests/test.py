import tilearn

print(tilearn.show(3, 4))