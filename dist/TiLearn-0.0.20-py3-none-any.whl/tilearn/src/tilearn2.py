from tilearn.src.tilearn1 import plus

def show(a, b):
    c = plus(a, b)
    return c